package com.lavochk.listTelegram;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.ChatColor;

public class WhitelistCommand implements CommandExecutor {

    private final ListTelegram plugin;

    public WhitelistCommand(ListTelegram plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.RED + "Usage: /" + label + " <reload|importstats>");
            return false;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("listtelegram.reload")) {
                sender.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
                return true;
            }
            plugin.reloadConfig();
            plugin.getWhitelistManager().load();
            sender.sendMessage(ChatColor.GREEN + "ListTelegram configuration and whitelist reloaded.");
            return true;

        } else if (args[0].equalsIgnoreCase("importstats")) {
            if (!sender.hasPermission("listtelegram.importstats")) {
                sender.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
                return true;
            }
            StatImporter importer = new StatImporter(plugin);
            importer.importStats(sender);
            return true;
        }

        sender.sendMessage(ChatColor.RED + "Unknown subcommand. Usage: /" + label + " <reload|importstats>");
        return false;
    }
}
