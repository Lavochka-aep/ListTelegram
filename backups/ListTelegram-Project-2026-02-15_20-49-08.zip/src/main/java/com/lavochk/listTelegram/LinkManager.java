package com.lavochk.listTelegram;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class LinkManager {

    private final File linkFile;
    private final FileConfiguration linkConfig;
    private final Map<String, Long> pendingLinks = new ConcurrentHashMap<>(); // Code -> Telegram ID

    public LinkManager(File dataFolder) {
        this.linkFile = new File(dataFolder, "links.yml");
        if (!linkFile.exists()) {
            try {
                linkFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        this.linkConfig = YamlConfiguration.loadConfiguration(linkFile);
    }

    public String generateLinkCode(long telegramId) {
        String code = UUID.randomUUID().toString().substring(0, 6);
        pendingLinks.put(code, telegramId);
        return code;
    }

    public boolean completeLink(String code, String playerName) {
        Long telegramId = pendingLinks.get(code);
        if (telegramId != null) {
            linkConfig.set(playerName, telegramId);
            save();
            pendingLinks.remove(code);
            return true;
        }
        return false;
    }

    public String getLinkedPlayer(long telegramId) {
        for (String key : linkConfig.getKeys(false)) {
            if (linkConfig.getLong(key) == telegramId) {
                return key;
            }
        }
        return null;
    }
    
    public boolean isLinked(long telegramId) {
        return getLinkedPlayer(telegramId) != null;
    }

    public void save() {
        try {
            linkConfig.save(linkFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
