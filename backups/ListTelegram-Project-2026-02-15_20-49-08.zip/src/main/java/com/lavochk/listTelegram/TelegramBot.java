package com.lavochk.listTelegram;

import org.bukkit.configuration.file.FileConfiguration;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.AnswerCallbackQuery;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.methods.send.SendPhoto;
import org.telegram.telegrambots.meta.api.methods.updatingmessages.EditMessageText;
import org.telegram.telegrambots.meta.api.objects.InputFile;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class TelegramBot extends TelegramLongPollingBot {

    private final ListTelegram plugin;
    private final FileLogger fileLogger;
    private final WhitelistManager whitelistManager;
    private final LinkManager linkManager;
    private final PlayerDataManager playerDataManager;
    private final String adminChatId;

    private enum UserState { AWAITING_NICKNAME, AWAITING_AGE, AWAITING_PLANS }
    private final Map<Long, UserState> userStates = new HashMap<>();
    private final Map<Long, WhitelistApplication> userApplications = new HashMap<>();

    public TelegramBot(ListTelegram plugin) {
        super(plugin.getConfig().getString("telegram.token"));
        this.plugin = plugin;
        this.fileLogger = plugin.getFileLogger();
        this.whitelistManager = plugin.getWhitelistManager();
        this.linkManager = plugin.getLinkManager();
        this.playerDataManager = plugin.getPlayerDataManager();
        this.adminChatId = plugin.getConfig().getString("telegram.admin-chat-id");
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {
            handleTextMessage(update.getMessage());
        } else if (update.hasCallbackQuery()) {
            handleCallbackQuery(update.getCallbackQuery());
        }
    }

    private void handleTextMessage(Message message) {
        long chatId = message.getChatId();
        String text = message.getText();

        if (userStates.containsKey(chatId)) {
            processApplicationStep(chatId, text);
            return;
        }

        switch (text) {
            case "/start":
            case "⬅️ Назад в меню":
                sendMainMenu(chatId);
                break;
            case "📝 Подать заявку":
                startApplication(chatId);
                break;
            case "🔗 Привязать аккаунт":
                startLinking(chatId);
                break;
            case "👤 Мой профиль":
                showProfile(chatId);
                break;
            case "👑 Админ-меню":
                if (String.valueOf(chatId).equals(adminChatId)) {
                    sendAdminMenu(chatId);
                }
                break;
            case "📋 Показать вайтлист":
                 if (String.valueOf(chatId).equals(adminChatId)) {
                    showWhitelist(chatId);
                }
                break;
            default:
                sendMessage(chatId, "Неизвестная команда. Используйте меню.");
                break;
        }
    }

    private void handleCallbackQuery(org.telegram.telegrambots.meta.api.objects.CallbackQuery callbackQuery) {
        String[] data = callbackQuery.getData().split(":");
        String action = data[0];

        if (action.equals("approve") || action.equals("deny")) {
            handleApplicationCallback(callbackQuery, data);
        } else if (action.equals("show_chart")) {
            handleChartCallback(callbackQuery, data);
        }
    }
    
    private void handleApplicationCallback(org.telegram.telegrambots.meta.api.objects.CallbackQuery callbackQuery, String[] data) {
        String action = data[0];
        String nickname = data[1];
        long userChatId = Long.parseLong(data[2]);
        String adminName = callbackQuery.getFrom().getFirstName();

        if (!(callbackQuery.getMessage() instanceof Message)) return;

        Message message = (Message) callbackQuery.getMessage();
        String originalMessage = message.getText();
        long adminChatId = message.getChatId();
        int messageId = message.getMessageId();

        if (action.equals("approve")) {
            whitelistManager.addPlayer(nickname);
            plugin.getLogger().info("Player '" + nickname + "' was added to the whitelist by " + adminName);
            fileLogger.log("APPROVED: Player '" + nickname + "' by " + adminName + ".");
            sendMessage(userChatId, "🎉 Поздравляем! Ваша заявка для ника '" + nickname + "' была одобрена. Добро пожаловать на сервер!");
            editMessage(adminChatId, messageId, originalMessage + "\n\n[✅ Одобрено пользователем " + adminName + "]");
        } else if (action.equals("deny")) {
            plugin.getLogger().info("Player '" + nickname + "' was denied by " + adminName);
            fileLogger.log("DENIED: Player '" + nickname + "' by " + adminName + ".");
            sendMessage(userChatId, "😔 К сожалению, ваша заявка для ника '" + nickname + "' была отклонена.");
            editMessage(adminChatId, messageId, originalMessage + "\n\n[❌ Отклонено пользователем " + adminName + "]");
        }
    }
    
    private void handleChartCallback(org.telegram.telegrambots.meta.api.objects.CallbackQuery callbackQuery, String[] data) {
        long chatId = callbackQuery.getMessage().getChatId();
        String playerName = data[1];
        
        FileConfiguration playerData = playerDataManager.getPlayerData(playerName);
        String chartUrl = ChartGenerator.generateChartUrl(playerData.getConfigurationSection("daily_playtime"));
        
        if (chartUrl != null) {
            sendPhoto(chatId, chartUrl, "📊 График активности для игрока " + playerName);
        } else {
            sendMessage(chatId, "Недостаточно данных для построения графика.");
        }
        
        // Answer the callback to remove the "loading" state on the button
        try {
            execute(new AnswerCallbackQuery(callbackQuery.getId()));
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }
    
    // --- Menu Methods ---

    private void sendMainMenu(long chatId) {
        ReplyKeyboardMarkup keyboardMarkup = new ReplyKeyboardMarkup();
        List<KeyboardRow> keyboard = new ArrayList<>();
        KeyboardRow row1 = new KeyboardRow();
        row1.add(new KeyboardButton("📝 Подать заявку"));
        row1.add(new KeyboardButton("🔗 Привязать аккаунт"));
        keyboard.add(row1);
        KeyboardRow row2 = new KeyboardRow();
        row2.add(new KeyboardButton("👤 Мой профиль"));
        keyboard.add(row2);

        if (String.valueOf(chatId).equals(adminChatId)) {
            KeyboardRow adminRow = new KeyboardRow();
            adminRow.add(new KeyboardButton("👑 Админ-меню"));
            keyboard.add(adminRow);
        }

        keyboardMarkup.setKeyboard(keyboard);
        keyboardMarkup.setResizeKeyboard(true);
        sendMessage(chatId, "👋 Выберите действие:", keyboardMarkup);
    }
    
    private void sendAdminMenu(long chatId) {
        ReplyKeyboardMarkup keyboardMarkup = new ReplyKeyboardMarkup();
        List<KeyboardRow> keyboard = new ArrayList<>();
        KeyboardRow row1 = new KeyboardRow();
        row1.add(new KeyboardButton("📋 Показать вайтлист"));
        keyboard.add(row1);
        KeyboardRow row2 = new KeyboardRow();
        row2.add(new KeyboardButton("⬅️ Назад в меню"));
        keyboard.add(row2);
        
        keyboardMarkup.setKeyboard(keyboard);
        keyboardMarkup.setResizeKeyboard(true);
        sendMessage(chatId, "👑 Админ-меню:", keyboardMarkup);
    }

    // --- Feature Methods ---

    private void startApplication(long chatId) {
        userStates.put(chatId, UserState.AWAITING_NICKNAME);
        userApplications.put(chatId, new WhitelistApplication());
        sendMessage(chatId, "📝 Начинаем подачу заявки.\n\n1. Какой ваш ник в Minecraft?");
    }

    private void startLinking(long chatId) {
        if (linkManager.isLinked(chatId)) {
            sendMessage(chatId, "✅ Ваш аккаунт уже привязан к игроку: " + linkManager.getLinkedPlayer(chatId));
            return;
        }
        String code = linkManager.generateLinkCode(chatId);
        sendMessage(chatId, "🔗 Для привязки аккаунта, зайдите на сервер и введите команду:\n\n`/link " + code + "`");
    }

    private void showProfile(long chatId) {
        String playerName = linkManager.getLinkedPlayer(chatId);
        if (playerName == null) {
            sendMessage(chatId, "ℹ️ Ваш Telegram аккаунт еще не привязан к игровому. Используйте кнопку 'Привязать аккаунт'.");
            return;
        }

        FileConfiguration data = playerDataManager.getPlayerData(playerName);
        boolean isWhitelisted = whitelistManager.isWhitelisted(playerName);
        
        long totalPlaytime = data.getLong("total_playtime", 0);
        String formattedPlaytime = formatDuration(totalPlaytime);
        
        long firstJoin = data.getLong("first_join", 0);
        String firstJoinDate = (firstJoin > 0) ? new SimpleDateFormat("dd.MM.yyyy").format(new Date(firstJoin)) : "неизвестно";
        
        long lastJoin = data.getLong("last_join", 0);
        String lastJoinDate = (lastJoin > 0) ? new SimpleDateFormat("dd.MM.yyyy HH:mm").format(new Date(lastJoin)) : "неизвестно";

        String messageText = "👤 Ваш профиль:\n\n" +
                             "- Ник: `" + playerName + "`\n" +
                             "- Статус: " + (isWhitelisted ? "✅ В белом списке" : "❌ Не в белом списке") + "\n" +
                             "- Общее время в игре: `" + formattedPlaytime + "`\n" +
                             "- Первый вход: `" + firstJoinDate + "`\n" +
                             "- Последний раз был онлайн: `" + lastJoinDate + "`";

        InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> rows = new ArrayList<>();
        List<InlineKeyboardButton> row = new ArrayList<>();
        InlineKeyboardButton chartButton = new InlineKeyboardButton();
        chartButton.setText("📊 График активности");
        chartButton.setCallbackData("show_chart:" + playerName);
        row.add(chartButton);
        rows.add(row);
        markup.setKeyboard(rows);

        sendMessage(chatId, messageText, markup);
    }
    
    private void showWhitelist(long chatId) {
        whitelistManager.load(); // Ensure we have the latest list
        List<String> players = whitelistManager.getWhitelistedPlayers();
        if (players.isEmpty()) {
            sendMessage(chatId, "📋 Белый список пуст.");
            return;
        }
        StringBuilder sb = new StringBuilder("📋 Игроки в белом списке:\n\n");
        for (String player : players) {
            sb.append("- `").append(player).append("`\n");
        }
        sendMessage(chatId, sb.toString());
    }

    private void processApplicationStep(long chatId, String message) {
        UserState state = userStates.get(chatId);
        WhitelistApplication app = userApplications.get(chatId);

        switch (state) {
            case AWAITING_NICKNAME:
                app.setNickname(message);
                userStates.put(chatId, UserState.AWAITING_AGE);
                sendMessage(chatId, "2. Сколько вам лет?");
                break;
            case AWAITING_AGE:
                app.setAge(message);
                userStates.put(chatId, UserState.AWAITING_PLANS);
                sendMessage(chatId, "3. Чем планируете заниматься на сервере?");
                break;
            case AWAITING_PLANS:
                app.setPlans(message);
                sendApplicationToAdmin(app, chatId);
                sendMessage(chatId, "✅ Ваша заявка отправлена на рассмотрение. Пожалуйста, ожидайте.");
                userStates.remove(chatId);
                userApplications.remove(chatId);
                break;
        }
    }

    private void sendApplicationToAdmin(WhitelistApplication app, long userChatId) {
        if (adminChatId == null || adminChatId.equals("YOUR_CHAT_ID") || adminChatId.isEmpty()) {
            plugin.getLogger().warning("Admin Chat ID is not configured in config.yml! Cannot send application.");
            return;
        }

        String applicationText = "📬 Новая заявка в белый список:\n\n" +
                "📝 Ник: " + app.getNickname() + "\n" +
                "🎂 Возраст: " + app.getAge() + "\n" +
                "🎯 Планы: " + app.getPlans();

        InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> rows = new ArrayList<>();
        List<InlineKeyboardButton> row = new ArrayList<>();

        InlineKeyboardButton approveButton = new InlineKeyboardButton();
        approveButton.setText("✅ Одобрить");
        approveButton.setCallbackData("approve:" + app.getNickname() + ":" + userChatId);

        InlineKeyboardButton denyButton = new InlineKeyboardButton();
        denyButton.setText("❌ Отклонить");
        denyButton.setCallbackData("deny:" + app.getNickname() + ":" + userChatId);

        row.add(approveButton);
        row.add(denyButton);
        rows.add(row);
        markup.setKeyboard(rows);

        sendMessage(Long.parseLong(adminChatId), applicationText, markup);
    }

    // --- Utility Methods ---

    private void sendMessage(long chatId, String text) {
        sendMessage(chatId, text, null);
    }

    private void sendMessage(long chatId, String text, org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboard markup) {
        SendMessage message = new SendMessage();
        message.setChatId(String.valueOf(chatId));
        message.setText(text);
        message.setParseMode("Markdown"); // Enable Markdown for code blocks
        if (markup != null) {
            message.setReplyMarkup(markup);
        }
        try {
            execute(message);
        } catch (TelegramApiException e) {
            plugin.getLogger().severe("Could not send Telegram message: " + e.getMessage());
        }
    }
    
    private void sendPhoto(long chatId, String photoUrl, String caption) {
        SendPhoto photo = new SendPhoto();
        photo.setChatId(String.valueOf(chatId));
        photo.setPhoto(new InputFile(photoUrl));
        photo.setCaption(caption);
        try {
            execute(photo);
        } catch (TelegramApiException e) {
            plugin.getLogger().severe("Could not send photo: " + e.getMessage());
        }
    }

    private void editMessage(long chatId, int messageId, String text) {
        EditMessageText editedMessage = new EditMessageText();
        editedMessage.setChatId(String.valueOf(chatId));
        editedMessage.setMessageId(messageId);
        editedMessage.setText(text);
        try {
            execute(editedMessage);
        } catch (TelegramApiException e) {
            plugin.getLogger().severe("Could not edit Telegram message: " + e.getMessage());
        }
    }
    
    private String formatDuration(long totalSeconds) {
        if (totalSeconds < 60) {
            return totalSeconds + " сек.";
        }
        long days = TimeUnit.SECONDS.toDays(totalSeconds);
        long hours = TimeUnit.SECONDS.toHours(totalSeconds) % 24;
        long minutes = TimeUnit.SECONDS.toMinutes(totalSeconds) % 60;
        
        StringBuilder sb = new StringBuilder();
        if (days > 0) sb.append(days).append(" д. ");
        if (hours > 0) sb.append(hours).append(" ч. ");
        if (minutes > 0) sb.append(minutes).append(" мин.");
        
        return sb.toString().trim();
    }

    @Override
    public String getBotUsername() {
        return "ListTelegramBot";
    }

    private static class WhitelistApplication {
        private String nickname, age, plans;
        public String getNickname() { return nickname; }
        public void setNickname(String nickname) { this.nickname = nickname; }
        public String getAge() { return age; }
        public void setAge(String age) { this.age = age; }
        public String getPlans() { return plans; }
        public void setPlans(String plans) { this.plans = plans; }
    }
}
