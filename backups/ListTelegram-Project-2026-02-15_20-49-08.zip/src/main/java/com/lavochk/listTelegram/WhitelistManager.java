package com.lavochk.listTelegram;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class WhitelistManager {

    private final File whitelistFile;
    private List<String> whitelistedPlayers;

    public WhitelistManager(File dataFolder) {
        this.whitelistFile = new File(dataFolder, "whitelist.txt");
        if (!whitelistFile.exists()) {
            try {
                whitelistFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        load();
    }

    public void load() {
        try {
            this.whitelistedPlayers = Files.readAllLines(whitelistFile.toPath()).stream()
                    .map(String::trim)
                    .filter(line -> !line.isEmpty() && !line.startsWith("#"))
                    .collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
            this.whitelistedPlayers = Collections.emptyList();
        }
    }

    public boolean isWhitelisted(String playerName) {
        return whitelistedPlayers.stream().anyMatch(p -> p.equalsIgnoreCase(playerName));
    }

    public void addPlayer(String playerName) {
        if (!isWhitelisted(playerName)) {
            whitelistedPlayers.add(playerName);
            try {
                Files.write(whitelistFile.toPath(), (playerName + System.lineSeparator()).getBytes(), StandardOpenOption.APPEND);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void removePlayer(String playerName) {
        if (isWhitelisted(playerName)) {
            whitelistedPlayers.removeIf(p -> p.equalsIgnoreCase(playerName));
            try {
                Files.write(whitelistFile.toPath(), whitelistedPlayers);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public List<String> getWhitelistedPlayers() {
        return Collections.unmodifiableList(whitelistedPlayers);
    }
}
