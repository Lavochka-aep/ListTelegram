package com.lavochk.listTelegram;

import java.util.Base64;
import java.util.UUID;

public class LicenseManager {

    private final ListTelegram plugin;
    private boolean isLicensed = false;
    private final String SECRET_PHRASE = "sIH-_rlLB7";

    public LicenseManager(ListTelegram plugin) {
        this.plugin = plugin;
        checkLicense();
    }

    public void checkLicense() {
        String key = plugin.getConfig().getString("license-key", "");
        if (key.isEmpty()) {
            this.isLicensed = false;
            return;
        }

        String currentToken = plugin.getConfig().getString("telegram.token", "");
        if (currentToken.isEmpty() || currentToken.equals("YOUR_BOT_TOKEN")) {
            this.isLicensed = false;
            return;
        }

        try {
            String decodedKey = new String(Base64.getDecoder().decode(key));
            String[] parts = decodedKey.split("_");

            if (parts.length != 3) {
                this.isLicensed = false;
                return;
            }

            String keyTokenPart = parts[0];
            String keySecretPart = parts[1];

            // 1. Check if the secret phrase matches
            if (!keySecretPart.equals(SECRET_PHRASE)) {
                this.isLicensed = false;
                return;
            }

            // 2. Check if the token part matches the current bot's token
            String currentTokenPart = currentToken.substring(0, Math.min(currentToken.length(), 15));
            this.isLicensed = keyTokenPart.equals(currentTokenPart);

        } catch (Exception e) {
            // Error decoding or splitting, key is invalid
            this.isLicensed = false;
        }
    }

    public boolean isLicensed() {
        return isLicensed;
    }

    public boolean activateLicense(String key) {
        plugin.getConfig().set("license-key", key);
        plugin.saveConfig();
        checkLicense();
        return isLicensed;
    }

    /**
     * Generates a license key based on the bot's API token.
     * @param apiToken The bot's full API token.
     * @return A generated license key.
     */
    public String generateLicenseKey(String apiToken) {
        if (apiToken.length() < 15) {
            return "ERROR: API token is too short.";
        }
        String tokenPart = apiToken.substring(0, 15);
        String randomPart = UUID.randomUUID().toString().substring(0, 6);

        String payload = tokenPart + "_" + SECRET_PHRASE + "_" + randomPart;
        return Base64.getEncoder().encodeToString(payload.getBytes());
    }
}
