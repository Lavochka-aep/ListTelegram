package com.lavochk.listTelegram;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatBridgeListener implements Listener {

    private final ListTelegram plugin;

    public ChatBridgeListener(ListTelegram plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        String chatBridgeGroupId = plugin.getConfig().getString("telegram.chat-bridge-group-id");
        if (chatBridgeGroupId == null || chatBridgeGroupId.isEmpty()) {
            return;
        }

        // Avoid sending back messages that came from Telegram
        if (event.getMessage().startsWith("[Telegram]")) {
            return;
        }

        String message = "[MC] " + event.getPlayer().getName() + ": " + event.getMessage();
        plugin.getTelegramBot().sendMessageToBridge(message);
    }
}
