package com.lavochk.listTelegram;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class AdManager implements Listener {

    private final LicenseManager licenseManager;
    private int messageCounter = 0;
    private final int MESSAGES_PER_AD = 50;

    public AdManager(LicenseManager licenseManager) {
        this.licenseManager = licenseManager;
    }

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        if (licenseManager.isLicensed()) {
            return;
        }

        messageCounter++;

        if (messageCounter >= MESSAGES_PER_AD) {
            messageCounter = 0;
            
            // Schedule tasks to run on the main server thread
            Bukkit.getScheduler().runTask(ListTelegram.getInstance(), () -> {
                // Public ad for all players
                Bukkit.broadcastMessage(" ");
                Bukkit.broadcastMessage(ChatColor.DARK_AQUA + "========================================");
                Bukkit.broadcastMessage(ChatColor.AQUA + " Этот сервер использует плагин ListTelegram");
                Bukkit.broadcastMessage(ChatColor.AQUA + "   Разработано командой @TheLastBurrow");
                Bukkit.broadcastMessage(ChatColor.DARK_AQUA + "========================================");
                Bukkit.broadcastMessage(" ");

                // Private ad for operators
                String adminAdLine1 = ChatColor.GREEN + "========================================";
                String adminAdLine2 = ChatColor.YELLOW + "  Плагин работает в бесплатном режиме.";
                String adminAdLine3 = ChatColor.AQUA + "  Купить лицензию и убрать рекламу: @Stumletop";
                String adminAdLine4 = ChatColor.GREEN + "========================================";

                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (player.isOp()) {
                        player.sendMessage(" ");
                        player.sendMessage(adminAdLine1);
                        player.sendMessage(adminAdLine2);
                        player.sendMessage(adminAdLine3);
                        player.sendMessage(adminAdLine4);
                        player.sendMessage(" ");
                    }
                }
                
                // Also send to console
                Bukkit.getConsoleSender().sendMessage(adminAdLine1);
                Bukkit.getConsoleSender().sendMessage(adminAdLine2);
                Bukkit.getConsoleSender().sendMessage(adminAdLine3);
                Bukkit.getConsoleSender().sendMessage(adminAdLine4);
            });
        }
    }
}
