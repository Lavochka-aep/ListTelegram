package com.lavochk.listTelegram;

/**
 * This class is intentionally left empty to resolve a build conflict.
 * The functionality has been replaced by ConsoleLogReader.
 * This file can be safely deleted.
 */
public class ConsoleLogAppender {
    // This class is intentionally left empty.
}
