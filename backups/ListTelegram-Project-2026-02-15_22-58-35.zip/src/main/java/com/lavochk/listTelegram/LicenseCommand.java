package com.lavochk.listTelegram;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LicenseCommand implements CommandExecutor {

    private final ListTelegram plugin;
    private final String requiredPassword = "123tujh123mine";

    public LicenseCommand(ListTelegram plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.RED + "Usage: /" + label + " <activate|generate>");
            return false;
        }

        if (args[0].equalsIgnoreCase("activate")) {
            if (args.length != 2) {
                sender.sendMessage(ChatColor.RED + "Usage: /" + label + " activate <key>");
                return true;
            }
            String key = args[1];
            if (plugin.getLicenseManager().activateLicense(key)) {
                sender.sendMessage(ChatColor.GREEN + "Лицензия успешно активирована! Реклама отключена.");
            } else {
                sender.sendMessage(ChatColor.RED + "Неверный или неактивный лицензионный ключ для этого сервера.");
            }
            return true;

        } else if (args[0].equalsIgnoreCase("generate")) {
            if (!sender.hasPermission("listtelegram.license.generate")) {
                sender.sendMessage(ChatColor.RED + "У вас нет прав для выполнения этой команды.");
                return true;
            }
            // Correctly check for 3 arguments: generate, password, api_token
            if (args.length != 3) {
                sender.sendMessage(ChatColor.RED + "Usage: /" + label + " generate <password> <api_token>");
                return true;
            }
            String password = args[1];
            String apiToken = args[2];

            if (!password.equals(requiredPassword)) {
                sender.sendMessage(ChatColor.RED + "Неверный пароль для генерации ключа.");
                return true;
            }

            if (apiToken.length() < 20) { // Basic sanity check for a token
                sender.sendMessage(ChatColor.RED + "Указанный API токен слишком короткий. Проверьте правильность ввода.");
                return true;
            }

            String generatedKey = plugin.getLicenseManager().generateLicenseKey(apiToken);
            sender.sendMessage(ChatColor.YELLOW + "Сгенерированный лицензионный ключ для указанного токена:");

            if (sender instanceof Player) {
                Player player = (Player) sender;
                TextComponent keyComponent = new TextComponent(generatedKey);
                keyComponent.setColor(net.md_5.bungee.api.ChatColor.WHITE);
                keyComponent.setClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, generatedKey));
                keyComponent.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("Нажмите, чтобы скопировать").color(net.md_5.bungee.api.ChatColor.GRAY).create()));
                player.spigot().sendMessage(keyComponent);
            } else {
                sender.sendMessage(ChatColor.WHITE + generatedKey);
            }
            return true;
        }

        return false;
    }
}
